module.exports = {
  getThreads: async () => 'bsubk',
}

// easy!
